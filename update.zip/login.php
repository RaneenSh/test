<!DOCTYPE HTML>
	<html>  
	<head>
	<style>
	div {
		width:300px;
		margin: auto;
		margin-top: 100px;
		border: 1px solid black;
		padding: 50px 30px 50px 80px;
	}
	table {
    border-collapse: collapse;
	}

	table, th, td {
		border: 1px solid black;
	}
	</style>
	</head>
	<body>
	<div>
	<form action="PersonalInfo.php" method="post">
	E-mail: <input type="text" name="email"><br><br>
	Password: <input type = "password" name = "password"><br><br>
	<input type="submit" name = "submit"><br>
	</form>
	<br>
	<form action="task2.php" method="post">
	<input type = "submit" value = "Back">
	</form>
	</div>
	</body>
</html>
