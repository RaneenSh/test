<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$database = "task2";
$conn = mysqli_connect($servername, $username, $password, $database);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$fname = $_POST['first'];
	$lname = $_POST['last'];
	$city = $_POST['cars'];
	$gender = $_POST['gender'];
	echo $gender;
	if(isset ($_POST['update'])){
		$stmt = $conn->prepare("UPDATE  signup SET first_name = ?, last_name = ?, city = ?, gender = ? WHERE password = ?");
		$pass = $_SESSION['password'];
		$password = crypt($pass, 123);
		echo $_SESSION['password'];
		$stmt->bind_param("sssss", $fname, $lname, $city, $gender, $password);
		$stmt->execute();
		echo "The account created successfully<br>";
		$stmt->close();
	}
	header('Location: PersonalInfo.php');
}


?>

<!DOCTYPE HTML>
	<html> 
	<body>
<form action="PersonalInfo.php" method="post">
	<input type = "submit" value = "Back">
	</form>
	<br>
	</body>
	</html>
