<!DOCTYPE html>
<html>
<head>
	<style>
	div {
		width:300px;
		margin: auto;
		margin-top: 150px;
		border: 1px solid black;
		padding: 50px 30px 50px 80px;
	}
	</style>
	</head>
<body>
<div>
<p><a href="sign_up">sign up</a></p>
<p><a href="login">login</a></p>
</div>
</body>
</html>
